# ensembl_variant_lookup/__init__.py
__version__ = '1.0.3'

from ensembl_variant_lookup import  *
